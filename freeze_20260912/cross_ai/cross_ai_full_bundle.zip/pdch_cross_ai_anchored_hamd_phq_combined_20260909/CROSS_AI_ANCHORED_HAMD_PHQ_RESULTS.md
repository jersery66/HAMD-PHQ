# PHQ + HAMD 两阶段 anchored 跨 AI 维度异构结果

本版本严格按会议定义执行：先在每个 AI 内按 A/B/C 选择该 AI 的最佳 condition，再在 AI 之间选择每个条目的负责人。两个量表分别使用 pooled OOF，不把量表分数直接混合。主表保留所有 AI，GLM 只作为其中一个共同参考模型。

## 核心结果

- PHQ189 的 CrossAI-A/B/C total MAE 分别为 3.427、3.433、3.408；C03-GLM 基线为 3.254。
- PHQ 三种 CrossAI route 相对 C03-GLM 的总分比较均为正向差值，说明在 189 人 pooled OOF 中没有获得总体收益。
- HAMD17 available 的 CrossAI-A/B/C total MAE 分别为 3.410、3.470、3.486；完整被试率分别约为 0.624–0.649。
- HAMD16 core 的 CrossAI-A/B/C 结果仍需和 WithinAI-GLM 同策略比较，不能只看相对 C03 的点估计。

## 稳定性

PHQ 三种 anchored route 的条目级最高选择频率范围为 0.32–1.00；HAMD 为 0.18–0.96。部分 HAMD 条目较稳定，但整体没有通用 route。

## 结论

这次结果已经回答了会议提出的跨 AI 异构问题：不同 AI 确实会在不同条目上被选择，但这种选择没有在 PHQ 中带来总分收益，在 HAMD 中也没有稳定超过 GLM 内部 condition routing。因此跨 AI 异构应作为探索性互补信息结果，不能宣布为最终评分方案。
