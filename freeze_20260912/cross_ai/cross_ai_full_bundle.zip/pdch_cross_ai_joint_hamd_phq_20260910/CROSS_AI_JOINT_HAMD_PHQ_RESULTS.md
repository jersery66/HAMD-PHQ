# PHQ + HAMD Direct Joint Cross-AI 结果

本版本按最新要求直接让所有 AI×condition 完整结果参与每个条目的竞争。它不拆分 AI 内部流程，不训练机器学习模型，不调用 LLM。

## 必须先看的候选池核对

`PHQ_CROSS_AI_JOINT_candidate_table.csv` 和 `HAMD_CROSS_AI_JOINT_candidate_table.csv` 保存每个 selection fold 的完整候选表，包括 A rho、B item MAE、coverage、候选池资格和各方法是否选中。所有 AI 的 C03 都作为候选保留。旧 anchored 结果通过 `CROSS_AI_old_method_audit.csv` 保留并单独标记。

## 方法层级

- `CrossAI-C03`：只允许不同条目更换 AI，condition 永远为 C03。
- `CrossAI-Joint-A`：直接最大化所有 AI×condition 的 corrected item-total rho。
- `CrossAI-Joint-B`：直接最小化所有 AI×condition 的 item MAE。
- `CrossAI-Conservative-C`：以 CrossAI-C03 为锚点，只有 baseline 落在 inner one-SE 集合之外时才切换。

## Joint-B sanity check

`PHQ_JointB_oldB_equivalence.csv`、`HAMD_JointB_oldB_equivalence.csv` 和 `JointB_oldB_equivalence_summary.csv` 比较旧 B 与直接 Joint-B 是否逐 fold、逐 item 相同。相同说明旧 B 的实现与直接联合 argmin 一致；不同则需要看候选池、support、指标和提前锁定 condition 的差异。

## 结果文件

- PHQ/HAMD candidate table、routes、OOF、performance、item performance 和 route stability 均在本目录。
- `CROSS_AI_old_method_audit.csv` 记录旧结果是否为 anchored/two-stage。
- HAMD 同时提供 `HAMD17_available`、`HAMD17_strict_complete` 和 `HAMD16_core`。
