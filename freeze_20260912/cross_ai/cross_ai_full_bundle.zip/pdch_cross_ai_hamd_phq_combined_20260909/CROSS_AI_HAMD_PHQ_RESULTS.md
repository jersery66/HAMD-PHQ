# PHQ + HAMD 跨 AI 维度异构合并结果表

本表将 PHQ189 和 HAMD99 按相同的 item-specific model+condition routing 逻辑合并整理。两种量表分别评价，原始 MAE 不直接跨量表比较。

## 关键结果

- PHQ189 CrossAI total MAE=3.328，C03-GLM=3.254，相对 C03-GLM 的 Δ=0.074；CrossAI item NAE=0.209，cancellation ratio=0.307。
- HAMD17 available CrossAI total MAE=3.480，C03-GLM=3.616，完整被试率=0.668。
- HAMD16 core CrossAI total MAE=3.342，C03-GLM=3.515；这只是去掉 H14 的方法学敏感性。
- PHQ CrossAI 联合 route 最高选择频率为 0.30–0.68；HAMD 为 0.22–0.98。高频 route 只在少数条目出现。

## 解释

跨 AI 维度异构在两个数据库中都能观察到。它表现为不同条目会选择不同 AI 或 condition，但 pooled OOF 没有证明一套跨 AI route 同时优于最强固定模型、条目误差和误差抵消。因此当前应把它写成“存在互补信息但 route 稳定性和总体收益不足”的探索性结果。

## 文件

- 主表：`CROSS_AI_HAMD_PHQ_main_table.csv`
- 全性能表：`CROSS_AI_HAMD_PHQ_performance.csv`
- 比较表：`CROSS_AI_HAMD_PHQ_comparisons.csv`
- 路由稳定性：`CROSS_AI_HAMD_PHQ_route_stability.csv`
- 方法边界：`CROSS_AI_HAMD_PHQ_method_boundary.csv`
